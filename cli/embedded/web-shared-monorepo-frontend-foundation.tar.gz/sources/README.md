# monorepo-frontend-foundation layer
