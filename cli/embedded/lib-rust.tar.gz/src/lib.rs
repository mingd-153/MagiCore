//! {{project_name}} — Rust library scaffolded by MagiCore

pub fn hello() -> &'static str {
    "Hello from {{project_name}}"
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hello() {
        assert_eq!(hello(), "Hello from {{project_name}}");
    }
}
