# {{project_name}}

Rust library project scaffolded by MagiCore.
