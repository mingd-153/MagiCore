const root = document.getElementById('app');
if (root) {
  root.innerHTML = `<main style="padding: 2rem; font-family: sans-serif">
    <h1>Welcome to {{ project_name }}</h1>
    <p>Powered by MagiCore & Vanilla TS</p>
  </main>`;
}
