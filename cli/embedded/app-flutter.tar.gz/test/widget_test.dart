import 'package:flutter_test/flutter_test.dart';

import '../lib/main.dart';

void main() {
  testWidgets('MagiCore Flutter scaffold starts', (tester) async {
    await tester.pumpWidget(const MagiCoreApp());
    expect(find.text('Hello from {{project_name}}'), findsOneWidget);
  });
}
