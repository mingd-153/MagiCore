# {{project_name}}

Flutter app project scaffolded by MagiCore.
