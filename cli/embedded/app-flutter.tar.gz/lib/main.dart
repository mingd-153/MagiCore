void main() {
  print('Hello from {{project_name}}');
}
