import 'package:flutter/material.dart';

void main() => runApp(const MagiCoreApp());

class MagiCoreApp extends StatelessWidget {
  const MagiCoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(body: Center(child: Text('Hello from {{project_name}}'))),
    );
  }
}
